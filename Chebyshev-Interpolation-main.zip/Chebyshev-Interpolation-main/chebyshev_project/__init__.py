"""Chebyshev Interpolation project package."""
